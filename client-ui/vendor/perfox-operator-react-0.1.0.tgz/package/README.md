# @perfox/operator-react

A **native React SDK** for the Perfox human-copilot **operator** experience. Your app builds the UI; this SDK
does all the plumbing — site-key auth, the operator REST + WebSocket, and the **in-browser voice** (the operator
hears and talks to the caller). One provider + one hook.

```bash
npm install @perfox/operator-react
# peer deps you already have: react, react-dom
```

## 1. Sign the operator on YOUR backend (the only server-side piece)

The operator identity must be **server-signed** — the site secret never touches the browser. Add ~5 lines to an
endpoint in your own backend that returns a `user_hash` for the logged-in operator:

```js
import { createHmac } from 'node:crypto';
// SITE_ID + SITE_SECRET come from Perfox Studio → Sites (operator-enabled site).
const user_hash = createHmac('sha256', SITE_SECRET)
  .update(`${SITE_ID}.${operator.external_id}`)   // canonical string
  .digest('hex');
// return { external_id: operator.external_id, name: operator.name, user_hash } to your frontend
```
(Any language: `user_hash = HMAC_SHA256(site_secret, "<site_id>.<external_id>")` as lowercase hex.)

## 2. Wrap your operator screen

```tsx
import { OperatorProvider } from '@perfox/operator-react';

<OperatorProvider config={{
  apiHost: 'https://acme-api.perfox.ai',
  siteId: 'sa_site_live_…',
  operator: { externalId: 'op-17', name: 'Alex', userHash },  // userHash from your backend
  workflowId: 'the-copilot-agent-workflow-id',                // optional
  autoAvailable: true,
}}>
  <YourOperatorConsole />
</OperatorProvider>
```

## 3. Build your UI with the hook

```tsx
import { useOperator } from '@perfox/operator-react';

function YourOperatorConsole() {
  const op = useOperator();
  return (
    <div>
      {/* presence */}
      <button onClick={() => op.setAvailability('available')}>Available</button>

      {/* inbound ring */}
      {op.incomingCall && (
        <div>
          Incoming from {op.incomingCall.caller}
          <button onClick={() => op.answer()}>Answer</button>
          <button onClick={() => op.decline()}>Decline</button>
        </div>
      )}

      {/* outbound */}
      <button onClick={() => op.dialOut('+919812345678')}>Dial</button>

      {/* in-call controls (voice is handled in-browser) */}
      {op.activeCall?.status === 'live' && (
        <div>
          <button onClick={() => op.setMicEnabled(!op.micEnabled)}>{op.micEnabled ? 'Mute' : 'Unmute'}</button>
          <button onClick={() => op.hold(!op.activeCall!.onHold)}>{op.activeCall!.onHold ? 'Resume' : 'Hold'}</button>
          <button onClick={() => op.transfer({ externalId: 'op-9', name: 'Sam' })}>Transfer</button>
          <button onClick={() => op.hangup()}>End</button>
        </div>
      )}

      {/* AI whispers (answers to the CUSTOMER) */}
      {op.whispers.map((w) => <div key={w.id}><b>{w.question}</b><p>{w.answer}</p></div>)}

      {/* operator "Ask the AI" */}
      <button onClick={() => op.ask('what are our refund terms?')}>Ask AI</button>
      {op.answers.map((a) => <div key={a.id}><b>{a.question}</b><p>{a.answer}</p></div>)}

      {/* live transcript + compliance */}
      {op.transcript.map((t, i) => <p key={i}><b>{t.speaker}:</b> {t.text}</p>)}
      {op.compliance && <span>Compliance: {op.compliance.indicator}</span>}

      {/* post-call */}
      {op.summary?.summary && <div>Summary: {op.summary.summary} · {op.summary.sentiment_label}</div>}
    </div>
  );
}
```

## `useOperator()` — the full surface

**State:** `connected` · `availability` · `incomingCall` · `activeCall {conversationId, sessionId, status, onHold, direction}` ·
`micEnabled` · `helpMe` · `verbosity` · `rich` · `transcript[]` · `whispers[]` (AI answers to the customer, streaming) ·
`answers[]` (your Ask-AI Q&A) · `kb[]` · `compliance` · `summary` · `error`.

**Actions:** `setAvailability(status)` · `answer(conversationId?)` · `decline()` · `dialOut(phone)` · `ask(question)` ·
`setHelpMe(bool)` · `setVerbosity(level, rich?)` · `hold(on)` · `transfer({externalId,name})` · `hangup()` ·
`setMicEnabled(bool)` · `transcribe(blob) → text` (dictation) · `logAction(id, action)`.

## Notes
- Serve your app over **HTTPS**; the browser prompts for **microphone** permission when a call starts.
- Your site's **allowed_origins** (in Studio → Sites) must include your app's origin, or requests 403.
- `livekit-client` is bundled as a dependency and lazy-loaded only when a call starts.
- Rings are delivered by polling (no push socket); `op.incomingCall` updates ~every 2.5s while available.
